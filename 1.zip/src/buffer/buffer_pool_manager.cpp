//===----------------------------------------------------------------------===//
//
//                         BusTub
//
// buffer_pool_manager.cpp
//
// Identification: src/buffer/buffer_pool_manager.cpp
//
// Copyright (c) 2015-2021, Carnegie Mellon University Database Group
//
//===----------------------------------------------------------------------===//

#include "buffer/buffer_pool_manager.h"

#include "common/exception.h"
#include "common/macros.h"
#include "storage/page/page_guard.h"

namespace bustub {

BufferPoolManager::BufferPoolManager(size_t pool_size, DiskManager *disk_manager, size_t replacer_k,
                                     LogManager *log_manager)
    : pool_size_(pool_size), disk_manager_(disk_manager), log_manager_(log_manager) {
  // we allocate a consecutive memory space for the buffer pool
  pages_ = new Page[pool_size_];
  replacer_ = std::make_unique<LRUKReplacer>(pool_size, replacer_k);

  // Initially, every page is in the free list.
  for (size_t i = 0; i < pool_size_; ++i) {
    free_list_.emplace_back(static_cast<int>(i));
  }
}

BufferPoolManager::~BufferPoolManager() { delete[] pages_; }

auto BufferPoolManager::NewPage(page_id_t *page_id) -> Page * {
  // if the free list is empty, we should pick the replacement frame from the replacer.
  if (!free_list_.empty()) {
    replacer_->Lock();
    frame_id_t frame_id = free_list_.front();
    free_list_.pop_front();
    page_id_t next_page_id = AllocatePage();
    *page_id = next_page_id;
    page_table_[*page_id] = frame_id;
    pages_[frame_id].page_id_ = next_page_id;
    // reset the memory and metadata for the new page.
    pages_[frame_id].ResetMemory();
    pages_[frame_id].pin_count_ = 1;
    replacer_->Unlock();
    replacer_->RecordAccess(frame_id);
    replacer_->SetEvictable(frame_id, false);
    return &pages_[frame_id];
  }
  // all the frames are currently pinned.
  frame_id_t frame_id;
  if (!replacer_->Evict(&frame_id)) {
    return nullptr;
  }
  replacer_->Remove(frame_id);
  replacer_->Lock();
  if (pages_[frame_id].IsDirty()) {
    disk_manager_->WritePage(pages_[frame_id].GetPageId(), pages_[frame_id].GetData());
    pages_[frame_id].is_dirty_ = false;
  }
  page_table_.erase(pages_[frame_id].GetPageId());
  page_id_t next_page_id = AllocatePage();
  *page_id = next_page_id;
  page_table_[next_page_id] = frame_id;
  pages_[frame_id].page_id_ = next_page_id;
  pages_[frame_id].ResetMemory();
  pages_[frame_id].pin_count_ = 1;
  replacer_->Unlock();
  replacer_->RecordAccess(frame_id);
  replacer_->SetEvictable(frame_id, false);
  return &pages_[frame_id];
}

auto BufferPoolManager::FetchPage(page_id_t page_id, [[maybe_unused]] AccessType access_type) -> Page * {
  // not found in the buffer pool
  frame_id_t frame_id;
  if (page_table_.find(page_id) == page_table_.end()) {
    // first pick a replacement frame in the free list
    if (!free_list_.empty()) {
      replacer_->Lock();
      frame_id = free_list_.front();
      free_list_.pop_front();
      char page_data[BUSTUB_PAGE_SIZE];
      disk_manager_->ReadPage(page_id, page_data);
      pages_[frame_id].ResetMemory();
      std::memcpy(pages_[frame_id].GetData(), page_data, BUSTUB_PAGE_SIZE);
      pages_[frame_id].page_id_ = page_id;
      // since it comes from a free list, we should set pin count to 1
      pages_[frame_id].pin_count_ = 1;
      page_table_[page_id] = frame_id;
      replacer_->Unlock();
    } else {
      // all the pages in the buffer bool can't be evicted.
      if (!replacer_->Evict(&frame_id)) {
        return nullptr;
      }
      replacer_->Remove(frame_id);
      replacer_->Lock();
      if (pages_[frame_id].IsDirty()) {
        disk_manager_->WritePage(pages_[frame_id].page_id_, pages_[frame_id].GetData());
        pages_[frame_id].is_dirty_ = false;
      }
      page_table_.erase(pages_[frame_id].GetPageId());
      char page_data[BUSTUB_PAGE_SIZE];
      disk_manager_->ReadPage(page_id, page_data);
      pages_[frame_id].ResetMemory();
      std::memcpy(pages_[frame_id].GetData(), page_data, BUSTUB_PAGE_SIZE);
      pages_[frame_id].page_id_ = page_id;
      pages_[frame_id].pin_count_ = 1;
      page_table_[page_id] = frame_id;
      replacer_->Unlock();
    }
  } else {  // found in the buffer pool
    replacer_->Lock();
    frame_id = page_table_[page_id];
    pages_[frame_id].pin_count_++;
    replacer_->Unlock();
  }
  replacer_->RecordAccess(frame_id);
  replacer_->SetEvictable(frame_id, false);
  return &pages_[frame_id];
}

auto BufferPoolManager::UnpinPage(page_id_t page_id, bool is_dirty, [[maybe_unused]] AccessType access_type) -> bool {
  // the page_id is not in the buffer pool.
  if (page_table_.find(page_id) == page_table_.end()) {
    return false;
  }
  frame_id_t frame_id = page_table_[page_id];
  // the pin count is already zero.
  if (pages_[frame_id].GetPinCount() <= 0) {
    return false;
  }
  replacer_->Lock();
  if (!pages_[frame_id].is_dirty_) {
    pages_[frame_id].is_dirty_ = is_dirty;
  }
  pages_[frame_id].pin_count_--;
  replacer_->Unlock();
  if (pages_[frame_id].pin_count_ == 0) {
    replacer_->SetEvictable(frame_id, true);
  }
  return true;
}

auto BufferPoolManager::FlushPage(page_id_t page_id) -> bool {
  // if the page_id is not in the buffer pool
  if (page_table_.find(page_id) == page_table_.end()) {
    return false;
  }
  replacer_->Lock();
  frame_id_t frame_id = page_table_[page_id];
  disk_manager_->WritePage(page_id, pages_[frame_id].GetData());
  pages_[frame_id].is_dirty_ = false;
  replacer_->Unlock();
  return true;
}

void BufferPoolManager::FlushAllPages() {
  for (size_t i = 0; i < pool_size_; i++) {
    FlushPage(pages_[i].GetPageId());
  }
}

auto BufferPoolManager::DeletePage(page_id_t page_id) -> bool {
  if (page_table_.find(page_id) == page_table_.end()) {
    return true;
  }
  // if the page has been pinned, then return false;
  frame_id_t frame_id = page_table_[page_id];
  if (pages_[frame_id].GetPinCount() != 0) {
    return false;
  }
  replacer_->Lock();
  page_table_.erase(page_id);
  replacer_->Unlock();
  replacer_->Remove(frame_id);
  replacer_->Lock();
  pages_[frame_id].ResetMemory();
  pages_[frame_id].pin_count_ = 0;
  free_list_.emplace_back(frame_id);
  DeallocatePage(page_id);
  replacer_->Unlock();
  return true;
}
auto BufferPoolManager::AllocatePage() -> page_id_t { return next_page_id_++; }

auto BufferPoolManager::FetchPageBasic(page_id_t page_id) -> BasicPageGuard {
  Page *page_ptr = FetchPage(page_id);
  BasicPageGuard page_guard(this, page_ptr);
  return page_guard;
}

auto BufferPoolManager::FetchPageRead(page_id_t page_id) -> ReadPageGuard {
  Page *page_ptr = FetchPage(page_id);
  page_ptr->RLatch();
  ReadPageGuard read_guard(this, page_ptr);
  return read_guard;
}

auto BufferPoolManager::FetchPageWrite(page_id_t page_id) -> WritePageGuard {
  Page *page_ptr = FetchPage(page_id);
  page_ptr->WLatch();
  WritePageGuard write_guard(this, page_ptr);
  return write_guard;
}

auto BufferPoolManager::NewPageGuarded(page_id_t *page_id) -> BasicPageGuard {
  Page *page_ptr = NewPage(page_id);
  BasicPageGuard page_guard(this, page_ptr);
  return page_guard;
}

}  // namespace bustub
