//===----------------------------------------------------------------------===//
//
//                         BusTub
//
// lru_k_replacer.cpp
//
// Identification: src/buffer/lru_k_replacer.cpp
//
// Copyright (c) 2015-2022, Carnegie Mellon University Database Group
//
//===----------------------------------------------------------------------===//

#include "buffer/lru_k_replacer.h"
#include "common/exception.h"

namespace bustub {

LRUKReplacer::LRUKReplacer(size_t num_frames, size_t k) : replacer_size_(num_frames), k_(k) {
  current_timestamp_ = time(nullptr);
}

auto LRUKReplacer::Evict(frame_id_t *frame_id) -> bool {
  latch_.lock();
  *frame_id = -1;
  for (auto &pair : node_store_) {
    auto node = pair.second;
    node.CalculateD(k_, current_timestamp_);
    pair.second = node;
  }
  for (auto pair : node_store_) {
    if (pair.second.IsEvitable()) {
      if (*frame_id < 0) {
        *frame_id = pair.first;
      } else {
        size_t dis_1;
        size_t dis_2;
        dis_1 = node_store_[*frame_id].GetD();
        dis_2 = pair.second.GetD();
        std::cout << "dis_1 = " << dis_1 << " dis_2 = " << dis_2 << std::endl;
        std::cout << "*frame id = " << *frame_id << " pair.second = " << pair.first << std::endl;
        // dis_1 and dis_2 are both +inf
        if (dis_1 == std::string::npos && dis_2 == std::string::npos) {
          // FIFO
          if (node_store_[*frame_id].FirstAccess() > pair.second.FirstAccess()) {
            *frame_id = pair.first;
          }
        }
        // else: just select the max k-distance.
        if (dis_1 < dis_2) {
          *frame_id = pair.first;
        }
      }
    }
  }
  // we should clear the evicted frame's access history.
  if (*frame_id >= 0) {
    node_store_[*frame_id].ClearHistory();
    curr_size_--;
    node_store_.erase(*frame_id);
  }
  latch_.unlock();
  return *frame_id >= 0;
}

void LRUKReplacer::RecordAccess(frame_id_t frame_id, [[maybe_unused]] AccessType access_type) {
  latch_.lock();
  BUSTUB_ASSERT((size_t)frame_id <= replacer_size_, "the frame id should smaller than the replacer_size");
  // if the frame_id has already been visited;
  if ((node_store_.find(frame_id)) != node_store_.end()) {
    node_store_[frame_id].AddOneMoreVisit(current_timestamp_, k_);
    latch_.unlock();
    return;
  }
  LRUKNode node(frame_id);
  node.AddOneMoreVisit(current_timestamp_, k_);
  node_store_[frame_id] = node;
  latch_.unlock();
}

void LRUKReplacer::SetEvictable(frame_id_t frame_id, bool set_evictable) {
  latch_.lock();
  auto ite = node_store_.find(frame_id);
  if (ite == node_store_.end()) {
    std::cerr << "can't set frame id where it doesn't exist in the replacer.";
  }
  LRUKNode knode = node_store_[frame_id];
  if (knode.IsEvitable() && !set_evictable) {
    // the curr_size should not be zero.
    curr_size_--;
  } else if (!knode.IsEvitable() && set_evictable) {
    curr_size_++;
  }
  knode.SetEvitable(set_evictable);
  node_store_[frame_id] = knode;
  latch_.unlock();
}

void LRUKReplacer::Remove(frame_id_t frame_id) {
  if (node_store_.find(frame_id) == node_store_.end()) {
    return;
  }
  latch_.lock();
  auto node = node_store_[frame_id];
  BUSTUB_ASSERT(node.IsEvitable(), "the node must be evitable");
  node_store_.erase(frame_id);
  curr_size_--;
  latch_.unlock();
}

auto LRUKReplacer::Size() -> size_t { return curr_size_; }

void LRUKReplacer::Lock() { latch_.lock(); }
void LRUKReplacer::Unlock() { latch_.unlock(); }
}  // namespace bustub
