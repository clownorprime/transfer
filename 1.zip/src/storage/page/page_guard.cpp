#include "storage/page/page_guard.h"
#include "buffer/buffer_pool_manager.h"

namespace bustub {

BasicPageGuard::BasicPageGuard(BasicPageGuard &&that) noexcept {
  bpm_ = that.bpm_;
  page_ = that.page_;
  // we can't unpin the same page twice.
  that.page_ = nullptr;
}

void BasicPageGuard::Drop() {
  if (page_ == nullptr) {
    return;
  }
  bpm_->UnpinPage(page_->GetPageId(), page_->IsDirty());
}

// if this object already has a page being guarded
auto BasicPageGuard::operator=(BasicPageGuard &&that) noexcept -> BasicPageGuard & {
  if (this->page_ == nullptr) {
    bpm_ = that.bpm_;
    page_ = that.page_;
    that.page_ = nullptr;
    return *this;
  }
  Drop();
  bpm_ = that.bpm_;
  page_ = that.page_;
  that.page_ = nullptr;
  return *this;
}

BasicPageGuard::~BasicPageGuard() { Drop(); };  // NOLINT

ReadPageGuard::ReadPageGuard(ReadPageGuard &&that) noexcept {
  guard_.bpm_ = that.guard_.bpm_;
  guard_.page_ = that.guard_.page_;
  that.guard_.page_ = nullptr;
};

auto ReadPageGuard::operator=(ReadPageGuard &&that) noexcept -> ReadPageGuard & {
  if (this->guard_.page_ == nullptr) {
    guard_.bpm_ = that.guard_.bpm_;
    guard_.page_ = that.guard_.page_;
    that.guard_.page_ = nullptr;
    return *this;
  }
  Drop();
  guard_.bpm_ = that.guard_.bpm_;
  guard_.page_ = that.guard_.page_;
  that.guard_.page_ = nullptr;
  return *this;
}

void ReadPageGuard::Drop() { guard_.Drop(); }

ReadPageGuard::~ReadPageGuard() { Drop(); }  // NOLINT

WritePageGuard::WritePageGuard(WritePageGuard &&that) noexcept {
  guard_.bpm_ = that.guard_.bpm_;
  guard_.page_ = that.guard_.page_;
  that.guard_.page_ = nullptr;
};

auto WritePageGuard::operator=(WritePageGuard &&that) noexcept -> WritePageGuard & {
  if (this->guard_.page_ == nullptr) {
    guard_.bpm_ = that.guard_.bpm_;
    that.guard_.page_ = nullptr;
    return *this;
  }
  Drop();
  guard_.bpm_ = that.guard_.bpm_;
  guard_.page_ = that.guard_.page_;
  that.guard_.page_ = nullptr;
  return *this;
}

void WritePageGuard::Drop() { guard_.Drop(); }

WritePageGuard::~WritePageGuard() { Drop(); }  // NOLINT

}  // namespace bustub
